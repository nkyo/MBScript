#!/usr/bin/env bash
a=2
b=2
res=$(expr "$a" + "$b")

echo "$res"
